# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['min_sublist']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'min-sublist',
    'version': '0.1.0',
    'description': 'Find a sublist with the smallest sum.',
    'long_description': None,
    'author': 'Thomas Breydo',
    'author_email': 'tbreydo@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
